#!/usr/bin/env python
import rospy
from lawn_mower.srv import *
import serial

def handle_sev_controller_cmd(req):
	try:
                        print 'req ',req
                        ser= serial.Serial('/dev/ttyUSB0', 9600,timeout =.1)
                        print 'connected'
                        ser.write(req.control_cmd)
                        response = "NO"
                        print 'going in while loop'
                        while True:
                                print 'In while loop'
                                                        
                                data= ser.readline()
                                if len(data)>0:
                                        response="done"			
                                        break
                        print 'pahuch rha'

	except Exception as ex :
                        print ("controller_aurdino.py : can't connect to aurdino")
                        print ex
                        response="ERROR"
	
	return controllerCMDResponse(response)

def controller_cmd_server():
	rospy.init_node('controller_cmd_server')
	s = rospy.Service('controller_cmd',controllerCMD, handle_sev_controller_cmd)
	print 'service controller_cmd ready for use'
	rospy.spin()



if __name__ == '__main__':
	
	controller_cmd_server()
